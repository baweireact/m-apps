import React, { Component } from 'react'
import { Switch, Route, Redirect } from 'react-router-dom'
import Login from '../views/Login'

export default class Router extends Component {
  render() {
    return (
      <Switch>
        <Redirect from="/" to="/login" exact></Redirect>
        <Route path="/login" component={Login}></Route>
      </Switch>
    )
  }
}
