import React, { Component } from 'react'

export default class Me extends Component {
  render() {
    return (
      <div className="m-main">
        me
      </div>
    )
  }
}
