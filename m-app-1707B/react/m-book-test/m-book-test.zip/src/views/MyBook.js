import React, { Component } from 'react'

export default class MyBook extends Component {
  render() {
    return (
      <div className="m-main">
        mybook
      </div>
    )
  }
}
