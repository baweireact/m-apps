import React, { Component } from 'react'

export default class Header extends Component {
  render() {
    return (
      <div className="m-header">
        小米书城
      </div>
    )
  }
}
