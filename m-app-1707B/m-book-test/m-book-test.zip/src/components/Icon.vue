<template>
  <span :class="['m-icon icon iconfont icon-' + type ]"></span>
</template>

<script>
export default {
  props: ['type']
}
</script>

<style>

</style>