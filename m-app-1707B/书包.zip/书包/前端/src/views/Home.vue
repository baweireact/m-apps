<template>
  <div>
    <Nav></Nav>
    <List></List>
  </div>
</template>

<script>
import Nav from '../components/Nav'
import List from '../components/List'

export default {
  components: {
    Nav,
    List
  }
}
</script>

<style>

</style>