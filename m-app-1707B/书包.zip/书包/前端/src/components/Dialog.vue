<template>
  <div class="m-dialog-wrap" :class="{active: visible}">

  </div>
</template>

<script>
export default {
  props: ['visible']
}
</script>

<style>

</style>