const urls = {
  login: '/api/login',
  getNav: '/api/nav',
  getList: '/api/list',
  getTaskList: '/api/task'
}

export default urls