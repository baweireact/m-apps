// pages/my-book/my-book.js
let { host } = getApp().globalData

Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    myBook: [],
    totalPrice: '',
    totalCount: ''
  },

  observers: {
    'myBook': function(myBook) {
      let totalPrice = 0, totalCount = 0
      myBook.forEach(item => {
        totalPrice += item.price * item.count
        totalCount += item.count
      })
      this.setData({
        totalCount,
        totalPrice
      })

      wx.request({
        url: `${host}/api/update`,
        data: {
          myBookNew: myBook
        },
        method:'post',
        success: res => {
          
        }
      })
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    handleAdd(e) {
      let { myBook } = this.data
      let { index } = e.mark
      myBook[index].count++
      this.setData({
        myBook
      })
    },
    handleSub(e) {
      let { myBook } = this.data
      let { index } = e.mark
      if (myBook[index].count > 1) {
        myBook[index].count--
        this.setData({
          myBook
        })
      }
    },
    handleInput(e) {
      let { myBook } = this.data
      let { index } = e.target.dataset
      myBook[index].count = e.detail.value.replace(/[^\d]/g, '') * 1
      this.setData({
        myBook
      })
    }
  },

  pageLifetimes: {
    show() {
      wx.request({
        url: `${host}/api/my_book`,
        success: res => {
          if (res.data.code === 200) {
            this.setData({
              myBook: res.data.data
            })
          }
        }
      })
    }
  }
})
