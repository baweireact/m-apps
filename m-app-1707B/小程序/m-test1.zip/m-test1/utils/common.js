module.exports = Behavior({
  methods: {
    handleSetTabbarBadge(text) {
      wx.setTabBarBadge({
        index: 1,
        text: text + '',
      })
    }
  }
})