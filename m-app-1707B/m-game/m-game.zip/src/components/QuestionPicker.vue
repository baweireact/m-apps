<template>
  <div>
    <div>{{question}}</div>
    <div v-for="(item, index) in currentList" :key="item.id">
      <Icon :active="item.checked" @click.native="handleSelect(index)"></Icon>
      {{item.text}}
    </div>
  </div>
</template>

<script>
import Icon from './Icon'

export default {
  computed: {
    question() {
      let questionList = this.$store.state.questionList
      let currentIndex = this.$store.state.currentIndex
      return questionList.length > 0 ? questionList[currentIndex].question : ''
    },
    currentList() {
      let questionList = this.$store.state.questionList
      let currentIndex = this.$store.state.currentIndex
      return questionList.length > 0 ? questionList[currentIndex].answerList : []
    }
  },
  components: {
    Icon
  },
  methods: {
    handleSelect(index) {
      let questionList = this.$store.state.questionList
      let currentIndex = this.$store.state.currentIndex
      questionList[currentIndex].answerList[index].checked = true
      questionList = JSON.parse(JSON.stringify(questionList))
      this.$store.commit({ type: 'setState', key: 'questionList', value: questionList })
      setTimeout(() => {
        if (currentIndex + 1 < questionList.length) {
          this.$store.commit({ type: 'setState', key: 'currentIndex', value: currentIndex + 1})
        } else {
          this.$router.push('/result')
        }
      }, 200)
    }
  },
  mounted() {
    this.$store.dispatch({ type: 'getQuestionList' })
  }
}
</script>

<style>

</style>