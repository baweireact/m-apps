<template>
  <div>
    <router-link to="/login">点击开始</router-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>