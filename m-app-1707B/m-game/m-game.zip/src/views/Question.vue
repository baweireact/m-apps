<template>
  <div>
    <QuestionPicker></QuestionPicker>
  </div>
</template>

<script>
import QuestionPicker from '../components/QuestionPicker'

export default {
  components: {
    QuestionPicker
  }
}
</script>

<style>

</style>