<template>
  <div class="m-main">
    个人中心
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>