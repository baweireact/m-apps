module.exports = {
  lintOnSave: false
}