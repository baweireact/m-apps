const urls = {
  login: '/api/login',
  list: '/api/list',
  myBooks: '/api/my_books',
  detail: '/api/detail/'
}

export default urls