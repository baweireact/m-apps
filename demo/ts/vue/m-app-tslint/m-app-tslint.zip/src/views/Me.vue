<template>
  <div class="m-main">
    个人中心
  </div>
</template>

<script lang="ts">
export default {

}
</script>

<style>

</style>