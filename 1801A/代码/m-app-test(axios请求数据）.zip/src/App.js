import React, { Component } from 'react'
import axios from 'axios'

export default class App extends Component {

  //挂载完，相当于vue里的mounted
  componentDidMount() {
    axios({
      url: '/api/list'
    }).then(res => {
      console.log(res)
    })
  }

  render() {
    return (
      <div>
        
      </div>
    )
  }
}
