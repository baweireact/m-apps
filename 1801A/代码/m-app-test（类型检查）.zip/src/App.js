import React, { Component } from 'react'
import Icon from './components/Icon'

export default class App extends Component {
  state = {
    visible: true,
    username: '',
    password: '',
    field: ''
  }

  //受控组件,field是动态的key
  handleInput(e, field) {
    this.setState({
      [field]: e.target.value
    })
  }

  //显示隐藏
  handleVisible() {
    this.setState({
      visible: !this.state.visible
    })
  }

  render() {
    return (
      <div>
        <div>
          <input value={this.state.username} onChange={(e) => this.handleInput(e, 'username')} placeholder="请输入用户名"></input>
        </div>
        <div>
          <input value={this.state.password} onChange={(e) => this.handleInput(e, 'password')} placeholder="请输入密码"></input>
          <Icon name={this.state.visible ? 'show' : 'hide'} className="m-login-icon" onClick={() => this.handleVisible()}></Icon>
        </div>
        <Icon name="shubao"></Icon>
      </div>
    )
  }
}
