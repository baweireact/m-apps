import React, { Component } from 'react'

export default class MyBooks extends Component {
  render() {
    return (
      <div className="m-main">
        书包
      </div>
    )
  }
}
