import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  //仓库
  state: {
    navList: [],
    currentId: 0
  },
  //同步
  mutations: {
    //修改仓库里的值
    setNavList(state, payload) {
      state.navList = payload.navList
    },
    setCurrentId(state, payload) {
      state.currentId = payload.currentId
    }
  },
  //异步
  actions: {
    //获取导航数据 https://vuex.vuejs.org/zh/guide/actions.html
    getNavList({ commit }) {
      axios({
        url: '/api/nav'
      }).then(res => {
        if (res.data.code === 200) {
          commit({ type: 'setNavList', navList: res.data.data })
        }
      })
    }
  },
  modules: {
  }
})
