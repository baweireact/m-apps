<template>
  <div>
    <Nav></Nav>
  </div>
</template>

<script>
import Nav from '../components/Nav'

export default {
  components: {
    Nav
  }
}
</script>

<style>

</style>