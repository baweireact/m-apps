import React, { Component } from 'react'

export default class MyBook extends Component {
  render() {
    return (
      <div className="m-main">
        2
      </div>
    )
  }
}
