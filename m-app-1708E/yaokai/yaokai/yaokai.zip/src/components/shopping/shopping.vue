<template>
    <div>
        购物车
        <Footer />
    </div>
</template>
<script>
import Footer from "../../../components/footer.vue"
export default {
    props:{

    },
    components:{
        Footer
    },
    data(){
        return {

        }
    },
    computed:{

    },
    methods:{

    },
    created(){

    },
    mounted(){

    }
}
</script>
<style scoped lang="">

</style>